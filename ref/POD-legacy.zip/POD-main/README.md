# Provision Over Docker

Allows for a parent directory's docker file to be executed as needed to provision ONE docker based deployment reverse proxied with Caddy

Also provides a simple to use and end-to-end encrypted database for use with HTML forms 

Contact Azzurro Technology at info@azzurro.tech for fit-for-use assurance services for open source projects.
