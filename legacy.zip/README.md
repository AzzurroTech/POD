# Personal Open Dashboard

This is the Azzurro Technology Platform

Based on the open source VICI project 

This is the basis for components build out with POD
